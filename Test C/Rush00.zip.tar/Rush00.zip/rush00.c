/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush00.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jzorreta <jzorreta@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/14 12:31:13 by jzorreta          #+#    #+#             */
/*   Updated: 2025/09/14 12:31:14 by jzorreta         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

#define TOPL 'o' //Top Left = serve para posicionar o caractere no topo a direita 
#define TOPR 'o' //Top Right = para colocar o caractere a direita do topo 
#define TOPM '-' //Top Midle = para posicionar o caratere ao (ao meio) do topo
#define MID '|' //Midle = para posicionar o caractere ao centro
#define MIDFILL ' ' //Midle Fill = para preencher com espacos em brancos ao meio
#define BOTL 'o' //Bottomm Left = para posicionar o caracatere a esquerda abaixo  
#define BOTR 'o' //Bottom Right = para posicionar o caractere a direita a abaixo
#define BOTM '-' //Bottomm Midle = para posicionar o caractere ao meio abaixo
#define NEWLINE '\n' //NewLine = para adicior nova linha abaixo

void	ft_putchar(char c); //Instancia da fu   ncao ft_putchar, que vai receber os caracteres das figuras
void	print_line(char left, char middle, char right, int width); //Essa funcao recebe as posicoes dos caracteres e a largura

int	rush(int x, int y) //Essa funcao reecebe as coordenadas dos caracteres (x = horizontal/linha, y = vertical/coluna)
{
	int	current_row; //Referencia a linha atual antes de inserir o caractere da figura

	if (x <= 0 || y <= 0) //Essa condicao verifica o valor das coordenadas, caso seja zero
		return (0); //retorna zero e a
	current_row = 0; //a linha atual recebe zero, no caso seria a primeira linha
	while (current_row < y) //Assim sendo, considerando que o eixo y tenha valor, executa os comandos abaixos enquanto enquanto a linha atual for menor que y
	{
		if (current_row == 0) //Antes de 
			print_line(TOPL, TOPM, TOPR, x);
		else if (current_row == y - 1)
			print_line(BOTL, BOTM, BOTR, x);
		else
			print_line(MID, MIDFILL, MID, x);
		current_row++;
	}
	return (0);
}

void	print_line(char left, char middle, char right, int width)
{
	int	i;

	if (width == 1)
	{
		ft_putchar(left);
		ft_putchar(NEWLINE);
		return ;
	}
	ft_putchar(left);
	i = 0;
	while (i < width - 2)
	{
		ft_putchar(middle);
		i++;
	}
	ft_putchar(right);
	ft_putchar(NEWLINE);
}
