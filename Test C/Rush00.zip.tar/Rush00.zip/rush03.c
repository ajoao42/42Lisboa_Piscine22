/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush03.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jzorreta <jzorreta@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/14 12:31:27 by jzorreta          #+#    #+#             */
/*   Updated: 2025/09/14 12:31:28 by jzorreta         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

#define TOPL 'A'
#define TOPM 'B'
#define TOPR 'C'
#define MID 'B'
#define MIDFILL ' '
#define BOTL 'A'
#define BOTM 'B'
#define BOTR 'C'
#define NEWLINE '\n'

void	ft_putchar(char c);
void	print_line(char left, char middle, char right, int width);

int	rush(int x, int y)
{
	int	current_row;

	if (x <= 0 || y <= 0)
		return (0);
	current_row = 0;
	while (current_row < y)
	{
		if (current_row == 0)
			print_line(TOPL, TOPM, TOPR, x);
		else if (current_row == y - 1)
			print_line(BOTL, BOTM, BOTR, x);
		else
			print_line(MID, MIDFILL, MID, x);
		current_row++;
	}
	return (0);
}

void	print_line(char left, char middle, char right, int width)
{
	int	i;

	if (width == 1)
	{
		ft_putchar(left);
		ft_putchar(NEWLINE);
		return ;
	}
	ft_putchar(left);
	i = 0;
	while (i < width - 2)
	{
		ft_putchar(middle);
		i++;
	}
	ft_putchar(right);
	ft_putchar(NEWLINE);
}
