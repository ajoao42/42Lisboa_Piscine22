/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putchar.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ajoao <ajoao@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/09/14 12:31:02 by jzorreta          #+#    #+#             */
/*   Updated: 2025/09/18 13:58:02 by ajoao            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}
//								rush(5, 3) 														rush(5, 1) 																		rush(1, 1)													rush(1, 5)																	rush(4, 4)																
//								5 colunas <> 3 linhas				5 colunas <> 1 linhas								1 linha <> 1 coluna				5 linhas <> 1 coluna							4 linhas <> 4 colunas
//  							o----o																		o---o																								o																						o																										o--0
//									|				|																																																																						|																										|		|
//									o----o																																																																						|																										|		|
//																																																																																					|																										o--o
//																																																																																					0																											